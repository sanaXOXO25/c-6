s1=int(input('enter the first side or triangle'))
s2=int(input('enter the second side of the triangle'))
s3=int(input('enter the third side of the triangle'))
if s1 == s2 and s2 == s3:
    print('equilateral triangle')
elif s1 == s2 and s2 != s3:
    print('isosceles triangle')
else:
    print('scalene triangle')
